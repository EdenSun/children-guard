package eden.sun.childrenguard.util;

public class RequestURLConstants {

	public static final String URL_LOGIN = "auth/login";
	public static final String URL_IS_FIRST_LOGIN = "auth/isFirstLogin";

}
