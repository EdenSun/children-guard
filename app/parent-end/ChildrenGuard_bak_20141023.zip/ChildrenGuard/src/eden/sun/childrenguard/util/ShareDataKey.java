package eden.sun.childrenguard.util;

public class ShareDataKey {

	public static final String PARENT_ACCESS_TOKEN = "accessToken";

}
