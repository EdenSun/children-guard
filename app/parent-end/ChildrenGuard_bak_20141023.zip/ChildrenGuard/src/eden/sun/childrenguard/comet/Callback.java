package eden.sun.childrenguard.comet;

public interface Callback {
	void onSuccess();
}
