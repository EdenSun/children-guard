/** Automatically generated file. DO NOT MODIFY */
package eden.sun.childrenguard;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}