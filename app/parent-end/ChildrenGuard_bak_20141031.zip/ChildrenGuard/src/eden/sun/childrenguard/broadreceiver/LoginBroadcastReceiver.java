package eden.sun.childrenguard.broadreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class LoginBroadcastReceiver extends BroadcastReceiver  {

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		
	}

}
