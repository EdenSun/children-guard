package eden.sun.childrenguard.util;

public class Config {
	public static final String BASE_URL = "http://169.7.231.104:8080/childrenguard-server/";
	public static final String BASE_URL_MVC = BASE_URL + "mvc/";
	public static final String BASE_URL_COMETD =  BASE_URL +  "cometd/";
	

}
