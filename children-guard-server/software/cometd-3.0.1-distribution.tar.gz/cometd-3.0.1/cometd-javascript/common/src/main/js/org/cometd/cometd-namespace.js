// Namespaces for the cometd implementation
this.org = this.org || {};
org.cometd = {};
