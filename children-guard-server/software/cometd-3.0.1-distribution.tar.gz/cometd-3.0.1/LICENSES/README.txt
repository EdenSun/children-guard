The cometd project is open source software that is distributed
under a mix of licenses that reflect the diverse heritage and
communities of the the various components.

Unless otherwise noted, the artistic license applies.

The cometd-java modules is made available under the apache-2.0 license.

The cometd-jquery module is dual licensed with the apache-2.0 or MIT license.

The cometd-dojox module is dual licensed with the academic free license 2.1 or new BSD license.

